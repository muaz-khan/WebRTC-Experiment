Make sure that you're using chrome DEV or BETA release.

This "chrome" extension is open-sourced and MIT-licenced at:
    https://github.com/muaz-khan/WebRTC-Experiment/tree/master/desktop-sharing

This demonstration is part of WebRTC Experiments by Muaz Khan:
    https://github.com/muaz-khan/WebRTC-Experiment
    
    www.WebRTC-Experiment.com
    www.RTCMultiConnection.org
    muazkh@gmail.com
    @muazkh and @WebRTCWeb
    
    https://github.com/muaz-khan